import time
import board
import busio
import digitalio

import adafruit_rfm9x
import adafruit_bmp280
import adafruit_gps

# gps setup
i2c = busio.I2C(board.GP27, board.GP26)  # has gps, temperature and pressure sensor on one pin
gps = adafruit_gps.GPS_GtopI2C(i2c)
gps.send_command(b'PMTK314,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0')
gps.send_command(b"PMTK220,1000")
last_print = time.monotonic()

# radio set up
spi = busio.SPI(clock=board.GP2, MOSI=board.GP3, MISO=board.GP4)
cs = digitalio.DigitalInOut(board.GP6)
reset = digitalio.DigitalInOut(board.GP7)
rfm9x = adafruit_rfm9x.RFM9x(spi, cs, reset, 433.0)

# temperature and pressure setup
bmp280_sensor = adafruit_bmp280.Adafruit_BMP280_I2C(i2c, address=0x76)

# board light
light = digitalio.DigitalInOut(board.GP25)
light.switch_to_output(value=True)
light_on = True

# other variables
take_image = False
send_image = False


def new_file():
    file = open("data.txt", 'w')
    file.write("")
    file.close()


def save():
    file = open("data.txt", 'a')
    file.write(f"{altitude},{temperature},{pressure}")
    file.close()


def read_temperature():
    return bmp280_sensor.temperature


def read_pressure():
    return bmp280_sensor.pressure


def read_altitude():
    return bmp280_sensor.altitude


def get_gps_location():
    gps.update()
    if gps.has_fix:
        return "{0:.6f}".format(gps.latitude), "{0:.6f}".format(gps.longitude)
    else:
        return "0", "0"


def send(to_send):
    rfm9x.send(to_send)


def try_read(timeout):
    return rfm9x.receive(timeout=timeout)


def rssi():
    return rfm9x.rssi


new_file()
while True:
    light_on = not light_on
    light.value = light_on
    loop_start_time = time.time()
    temperature = read_temperature()
    pressure = read_pressure()
    altitude = read_altitude()
    lat, long = get_gps_location()
    try:
        rssi = rssi()
    except:
        rssi = -121
    try:
        message = "data|{0:.3f}|{1:.3f}|{2:.3f}|{3}|{4}|{5}".format(altitude, temperature, pressure, lat, long, rssi)
        send(message)
        save()

    except:
        print("this isnt ment to appear....")
        
    time.sleep((1.0 - ((time.time() - loop_start_time) % 1.0)))
    
